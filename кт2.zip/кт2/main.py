from flask import Flask, render_template
import random

app = Flask(__name__)

quotes = [
    '67',
    '52',
    '42'
]

@app.route('/')
def index():

    random_quote = random.choice(quotes)
    return render_template('index.html', quote=random_quote)

if __name__ == '__main__':
    app.run(debug=True)